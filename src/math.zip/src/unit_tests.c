#include <check.h>
#include <limits.h>
#include <math.h>
#include <stdlib.h>

#include "s21_math.h"

START_TEST(absTest_1) { ck_assert_int_eq(abs(-4), s21_abs(-4)); }
END_TEST

START_TEST(absTest_2) {
  ck_assert_int_eq(abs(2147483647), s21_abs(2147483647));
}
END_TEST

START_TEST(absTest_3) {
  ck_assert_int_eq(abs(-2147483647), s21_abs(-2147483647));
}
END_TEST

START_TEST(acosTest_1) {
  float a = 0.43;
  ck_assert_int_eq(acos(a), s21_acos(a));
}
END_TEST

START_TEST(acosTest_2) {
  float a = -0.24;
  ck_assert_int_eq(acos(a), s21_acos(a));
}
END_TEST

START_TEST(acosTest_3) {
  float a = 0;
  ck_assert_int_eq(acos(a), s21_acos(a));
}
END_TEST

START_TEST(acosTest_4) {
  float a = 1;
  ck_assert_int_eq(acos(a), s21_acos(a));
}
END_TEST

START_TEST(acosTest_5) {
  float a = -1;
  ck_assert_int_eq(acos(a), s21_acos(a));
}
END_TEST

START_TEST(acosTest_6) {
  float a = -23;
  ck_assert_int_eq(acos(a), s21_acos(a));
}
END_TEST

START_TEST(asinTest_1) {
  float a = -0.70;
  ck_assert_int_eq(asin(a), s21_asin(a));
}
END_TEST

START_TEST(asinTest_2) {
  float a = 2;
  ck_assert_int_eq(asin(a), s21_asin(a));
}
END_TEST

START_TEST(asinTest_3) {
  float a = -1;
  ck_assert_int_eq(asin(a), s21_asin(a));
}
END_TEST

START_TEST(asinTest_4) {
  float a = 1;
  ck_assert_int_eq(asin(a), s21_asin(a));
}
END_TEST

START_TEST(atanTest_1) {
  float a = -0.65;
  ck_assert_int_eq(atan(a), s21_atan(a));
}
END_TEST

START_TEST(atanTest_2) {
  float a = -1;
  ck_assert_int_eq(atan(a), s21_atan(a));
}
END_TEST

START_TEST(atanTest_3) {
  float a = 1;
  ck_assert_int_eq(atan(a), s21_atan(a));
}
END_TEST

START_TEST(atanTest_4) {
  float a = -2.1;
  ck_assert_int_eq(atan(a), s21_atan(a));
}
END_TEST

START_TEST(atanTest_5) {
  float a = 3.45;
  ck_assert_int_eq(atan(a), s21_atan(a));
}
END_TEST

START_TEST(ceilTest_1) { ck_assert_int_eq(ceil(2.83), s21_ceil(2.83)); }
END_TEST

START_TEST(ceilTest_2) { ck_assert_int_eq(ceil(-4.23), s21_ceil(-4.23)); }
END_TEST

START_TEST(ceilTest_3) { ck_assert_int_eq(ceil(523), s21_ceil(523)); }
END_TEST

START_TEST(ceilTest_4) {
  double a = 1.0 / 0.0;
  ck_assert_int_eq(ceil(a), s21_ceil(a));
}
END_TEST

START_TEST(cosTest_1) {
  float a = 1.0 / 0.0;
  ck_assert_int_eq(cos(a), s21_cos(a));
}
END_TEST

START_TEST(cosTest_2) {
  float a = 3.15;
  ck_assert_int_eq(cos(a), s21_cos(a));
}
END_TEST

START_TEST(cosTest_3) {
  float a = -5;
  ck_assert_int_eq(cos(a), s21_cos(a));
}
END_TEST

START_TEST(expTest_1) { ck_assert_int_eq(exp(2), s21_exp(2)); }
END_TEST

START_TEST(expTest_2) { ck_assert_int_eq(exp(-10), s21_exp(-10)); }
END_TEST

START_TEST(expTest_3) { ck_assert_int_eq(exp(20), s21_exp(20)); }
END_TEST

START_TEST(expTest_4) {
  double a = 0.0 / 0.0;
  ck_assert_int_eq(exp(a), s21_exp(a));
}
END_TEST

START_TEST(fabsTest_1) { ck_assert_int_eq(fabs(-23.20), s21_fabs(-23.20)); }
END_TEST

START_TEST(fabsTest_2) { ck_assert_int_eq(fabs(52.64), s21_fabs(52.64)); }
END_TEST

START_TEST(fabsTest_3) {
  ck_assert_int_eq(fabs(171.365452), s21_fabs(171.365452));
}
END_TEST

START_TEST(floorTest_1) { ck_assert_int_eq(floor(253), s21_floor(253)); }
END_TEST

START_TEST(floorTest_2) { ck_assert_int_eq(floor(-280), s21_floor(-280)); }
END_TEST

START_TEST(floorTest_3) { ck_assert_int_eq(floor(256.3), s21_floor(256.3)); }
END_TEST

START_TEST(floorTest_4) {
  double a = -25.73;
  ck_assert_int_eq(floor(a), s21_floor(a));
}
END_TEST

START_TEST(floorTest_5) {
  double a = 1.0 / 0.0;
  ck_assert_int_eq(floor(a), s21_floor(a));
}
END_TEST

START_TEST(floorTest_6) {
  double a = 0.0 / 0.0;
  ck_assert_int_eq(floor(a), s21_floor(a));
}
END_TEST

START_TEST(floorTest_7) {
  double a = -1.0 / 0.0;
  ck_assert_int_eq(floor(a), s21_floor(a));
}
END_TEST

START_TEST(fmodTest_1) { ck_assert_int_eq(fmod(20, 10), s21_fmod(20, 10)); }
END_TEST

START_TEST(fmodTest_2) { ck_assert_int_eq(fmod(-50, 80), s21_fmod(-50, 80)); }
END_TEST

START_TEST(fmodTest_3) { ck_assert_int_eq(fmod(30, -10), s21_fmod(30, -10)); }
END_TEST

START_TEST(fmodTest_6) { ck_assert_int_eq(fmod(-12, -5), s21_fmod(-12, -5)); }
END_TEST

START_TEST(fmodTest_4) {
  double a = 0.0 / 0.0, b = 12;
  ck_assert_int_eq(fmod(a, b), s21_fmod(a, b));
}
END_TEST

START_TEST(fmodTest_5) {
  double a = 35, b = 0;
  ck_assert_int_eq(fmod(a, b), s21_fmod(a, b));
}
END_TEST

START_TEST(logTest_1) { ck_assert_int_eq(log(40), s21_log(40)); }
END_TEST

START_TEST(logTest_2) { ck_assert_int_eq(log(-300), s21_log(-300)); }
END_TEST

START_TEST(logTest_3) { ck_assert_int_eq(log(32.5), s21_log(32.5)); }
END_TEST

START_TEST(logTest_4) {
  double a = 2.83;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(logTest_5) {
  double a = 2;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(logTest_6) {
  double a = 1.0 / 0.0;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(logTest_7) {
  double a = -10;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(logTest_8) {
  double a = 0.25;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(logTest_9) {
  double a = 0.0 / 0.0;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(logTest_10) {
  double a = 0.0;
  ck_assert_uint_eq(s21_log(a), log(a));
}
END_TEST

START_TEST(powTest_1) { ck_assert_double_eq(pow(2, 10), s21_pow(2, 10)); }
END_TEST

START_TEST(powTest_2) { ck_assert_double_eq(pow(-4, -2), s21_pow(-4, -2)); }
END_TEST

START_TEST(powTest_3) { ck_assert_double_eq(pow(10, -3), s21_pow(10, -3)); }
END_TEST

START_TEST(powTest_4) {
  ck_assert_double_eq_tol(pow(25, 0.5), s21_pow(25, 0.5), 1e-06);
}
END_TEST

START_TEST(powTest_5) { ck_assert_double_eq(pow(-13, 2), s21_pow(-13, 2)); }
END_TEST

START_TEST(powTest_6) {
  double a = 0, b = 0;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_7) {
  double a = 1.0 / 0.0, b = 0;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_8) {
  double a = 0.0 / 0.0, b = 0;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_10) {
  double a = 2, b = 1.0 / 0.0;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_11) {
  double a = 2, b = 0.0;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_12) {
  double a = -1, b = 1;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_13) {
  double a = INT_MIN, b = 1;
  ck_assert_double_eq_tol(pow(a, b), s21_pow(a, b), 1e-06);
}
END_TEST

START_TEST(powTest_14) {
  double a = -INT_MAX, b = 1;
  ck_assert_double_eq_tol(pow(a, b), s21_pow(a, b), 1e-06);
}
END_TEST

START_TEST(powTest_15) {
  double a = 100, b = 0;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_16) {
  double a = 0, b = 100;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_17) {
  double a = 100, b = 1;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_18) {
  double a = 1, b = 100;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_19) {
  double a = 13, b = 501;
  ck_assert_double_eq(pow(a, b), s21_pow(a, b));
}
END_TEST

START_TEST(powTest_21) {
  double a = 0.02, b = 0.4;
  ck_assert_double_eq_tol(pow(a, b), s21_pow(a, b), 1e-06);
}
END_TEST

START_TEST(powTest_22) { ck_assert_double_nan(s21_pow(-10, 9.1)); }
END_TEST

START_TEST(powTest_23) { ck_assert_double_nan(s21_pow(25, 0.0 / 0.0)); }
END_TEST

START_TEST(powTest_24) {
  ck_assert_int_eq(s21_pow(S21_INF, 1.1), pow(S21_INF, 1.1));
}
END_TEST

START_TEST(powTest_25) {
  long double orig_res = pow(S21_NAN, 1.1), our_res = s21_pow(S21_NAN, 1.1);
  int suc = 0;
  if (isnan(our_res) && isnan(orig_res)) suc = 1;
  ck_assert_int_eq(1, suc);
}
END_TEST

START_TEST(powTest_26) {
  double num = S21_NAN;
  double ex = S21_NAN;
  long double orig_res = pow(num, ex), our_res = s21_pow(num, ex);
  int suc = 0;
  if (isnan(our_res) && isnan(orig_res)) suc = 1;
  ck_assert_int_eq(1, suc);
}
END_TEST

START_TEST(powTest_27) {
  ck_assert_double_eq(pow(S21_INF, S21_INF), s21_pow(S21_INF, S21_INF));
}
END_TEST

START_TEST(powTest_28) {
  long double base = -16.161435;
  long double exp = 9.;
  ck_assert_float_eq_tol(s21_pow(-16.161435, 9.), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(powTest_29) {
  ck_assert_double_nan(s21_pow(-10.1261, -0.72));
  ck_assert_double_nan(pow(-10.1261, -0.72));
}
END_TEST

START_TEST(powTest_30) {
  long double base = +0;
  long double exp = -0.33;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(powTest_31) {
  double base = 0.;
  double exp = -2;
  ck_assert_double_eq(s21_pow(base, exp), pow(base, exp));
}
END_TEST

START_TEST(sinTest_1) {
  float a = 1.0 / 0.0;
  ck_assert_int_eq(sin(a), s21_sin(a));
}
END_TEST

START_TEST(sinTest_2) {
  float a = 1.2;
  ck_assert_int_eq(sin(a), s21_sin(a));
}
END_TEST

START_TEST(sinTest_3) {
  float a = -4;
  ck_assert_int_eq(sin(a), s21_sin(a));
}
END_TEST

START_TEST(sinTest_4) {
  float a = 5;
  ck_assert_int_eq(sin(a), s21_sin(a));
}
END_TEST

START_TEST(sqrtTest_1) { ck_assert_int_eq(sqrt(25), s21_sqrt(25)); }
END_TEST

START_TEST(sqrtTest_2) { ck_assert_int_eq(sqrt(143), s21_sqrt(143)); }
END_TEST

START_TEST(sqrtTest_3) { ck_assert_int_eq(sqrt(-253), s21_sqrt(-253)); }
END_TEST

START_TEST(sqrtTest_4) { ck_assert_int_eq(sqrt(0.0), s21_sqrt(0.0)); }
END_TEST

START_TEST(sqrtTest_5) {
  double a = 0.0 / 0.0;
  ck_assert_int_eq(sqrt(a), s21_sqrt(a));
}
END_TEST

START_TEST(tanTest_1) {
  float a = 1.0 / 0.0;
  ck_assert_int_eq(tan(a), s21_tan(a));
}
END_TEST

START_TEST(tanTest_2) {
  float a = 1;
  ck_assert_int_eq(tan(a), s21_tan(a));
}
END_TEST

START_TEST(tanTest_3) {
  float a = 0;
  ck_assert_int_eq(tan(a), s21_tan(a));
}
END_TEST

START_TEST(tanTest_4) {
  float a = -2;
  ck_assert_int_eq(tan(a), s21_tan(a));
}
END_TEST

START_TEST(pow_1) { ck_assert_double_eq(pow(-1, 1), s21_pow(-1, 1)); }
END_TEST

START_TEST(pow_2) {
  ck_assert_double_eq_tol(pow(INT_MIN, 1), s21_pow(INT_MIN, 1), 1e-06);
}
END_TEST

START_TEST(pow_3) {
  ck_assert_double_eq_tol(pow(-INT_MAX, 1), s21_pow(-INT_MAX, 1), 1e-06);
}
END_TEST

START_TEST(pow_4) { ck_assert_double_eq(pow(2, 2), s21_pow(2, 2)); }
END_TEST

START_TEST(pow_5) {
  ck_assert_double_eq_tol(pow(2.2, 2.2), s21_pow(2.2, 2.2), 1e-06);
}
END_TEST

START_TEST(pow_6) {
  ck_assert_double_eq_tol(pow(2, 0.5), s21_pow(2, 0.5), 1e-06);
}
END_TEST

START_TEST(pow_7) {
  ck_assert_ldouble_eq_tol(pow(0.9, 20), s21_pow(0.9, 20), 1e-06);
}
END_TEST

START_TEST(pow_8) { ck_assert_double_eq(pow(0.9, -20), s21_pow(0.9, -20)); }
END_TEST

START_TEST(pow_9) { ck_assert_double_eq(pow(100, 100), s21_pow(100, 100)); }
END_TEST

START_TEST(pow_10) { ck_assert_double_eq(pow(100, 0), s21_pow(100, 0)); }
END_TEST

START_TEST(pow_11) { ck_assert_double_eq(pow(0, 100), s21_pow(0, 100)); }
END_TEST

START_TEST(pow_12) { ck_assert_double_eq(pow(100, 1), s21_pow(100, 1)); }
END_TEST

START_TEST(pow_13) { ck_assert_double_eq(pow(1, 100), s21_pow(1, 100)); }
END_TEST

START_TEST(pow_14) { ck_assert_double_eq(pow(13, 501), s21_pow(13, 501)); }
END_TEST

START_TEST(pow_15) {
  ck_assert_double_eq_tol(pow(87.78, 13), s21_pow(87.78, 13), 1e-06);
}
END_TEST

START_TEST(pow_16) {
  ck_assert_double_eq_tol(pow(0.02, 0.4), s21_pow(0.02, 0.4), 1e-06);
}
END_TEST

START_TEST(pow_17) { ck_assert_double_nan(s21_pow(-10, 9.1)); }
END_TEST

START_TEST(pow_19) {
  ck_assert_int_eq(s21_pow(S21_INF, 1.1), pow(S21_INF, 1.1));
}
END_TEST

START_TEST(pow_20) {
  long double orig_res = pow(NAN, 1.1), our_res = s21_pow(NAN, 1.1);
  int suc = 0;
  if (isnan(our_res) && isnan(orig_res)) suc = 1;
  ck_assert_int_eq(1, suc);
}
END_TEST

START_TEST(pow_21) {
  double num = NAN;
  double ex = NAN;
  long double orig_res = pow(num, ex), our_res = s21_pow(num, ex);
  int suc = 0;
  if (isnan(our_res) && isnan(orig_res)) suc = 1;
  ck_assert_int_eq(1, suc);
}
END_TEST

START_TEST(pow_22) {
  double num = 0.001;
  double ex = NAN;
  long double orig_res = pow(num, ex), our_res = s21_pow(num, ex);
  int suc = 0;
  if (isnan(our_res) && isnan(orig_res)) suc = 1;
  ck_assert_int_eq(1, suc);
}
END_TEST

START_TEST(pow_23) {
  ck_assert_double_eq(pow(S21_INF, S21_INF), s21_pow(S21_INF, S21_INF));
}
END_TEST

START_TEST(pow_24) {
  long double base = -16.161435;
  long double exp = 9.;
  ck_assert_float_eq_tol(s21_pow(-16.161435, 9.), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_25) {
  ck_assert_double_nan(s21_pow(-10.1261, -0.72));
  ck_assert_double_nan(pow(-10.1261, -0.72));
}
END_TEST

START_TEST(pow_26) {
  long double base = +0;
  long double exp = -0.33;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(pow_27) {
  long double base = -0;
  long double exp = -0.33;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(pow_28) {
  ck_assert_ldouble_eq_tol(s21_pow(-0, S21_INF), pow(-0, S21_INF), 1e-06);
}
END_TEST

START_TEST(pow_29) {
  long double base = +0;
  long double exp = 123;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_30) {
  long double base = -0;
  long double exp = 123;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_31) {
  long double base = -0;
  long double exp = S21_INF;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_32) { ck_assert_ldouble_infinite(s21_pow(S21_NINF, S21_INF)); }
END_TEST

START_TEST(pow_33) {
  long double base = -1;
  long double exp = S21_NAN;
  ck_assert_double_nan(pow(base, exp));
  ck_assert_double_nan(s21_pow(base, exp));
}
END_TEST

START_TEST(pow_34) {
  ck_assert_ldouble_eq_tol(s21_pow(NAN, 0), pow(NAN, 0), 1e-06);
}
END_TEST

START_TEST(pow_35) {
  long double base = -123;
  long double exp = S21_NAN;
  ck_assert_double_nan(s21_pow(base, exp));
  ck_assert_double_nan(pow(base, exp));
}
END_TEST

START_TEST(pow_36) {
  ck_assert_ldouble_infinite(pow(0.5591951, S21_NINF));
  ck_assert_ldouble_infinite(s21_pow(0.5591951, S21_NINF));
}
END_TEST

START_TEST(pow_37) {
  long double base = 1.5591951;
  long double exp = S21_NINF;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_38) {
  long double base = 0.5591951;
  long double exp = S21_INF;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_39) {
  long double base = 1.5591951;
  long double exp = S21_INF;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(pow_40) {
  long double base = S21_NINF;
  long double exp = -193491;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_41) {
  long double base = S21_NINF;
  long double exp = -142;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_42) {
  long double base = S21_NINF;
  long double exp = 141;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(pow_43) {
  long double base = S21_NINF;
  long double exp = 142;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(pow_44) {
  long double base = S21_INF;
  long double exp = -1;
  ck_assert_ldouble_eq_tol(s21_pow(base, exp), pow(base, exp), 1e-06);
}
END_TEST

START_TEST(pow_45) {
  long double base = S21_INF;
  long double exp = 1;
  ck_assert_ldouble_infinite(s21_pow(base, exp));
  ck_assert_ldouble_infinite(pow(base, exp));
}
END_TEST

START_TEST(pow_46) {
  ck_assert_ldouble_eq_tol(s21_pow(0.0, 0.0), pow(0.0, 0.0), 1e-06);
}
END_TEST

START_TEST(pow_47) {
  ck_assert_ldouble_eq_tol(s21_pow(-1, 4), pow(-1, 4), 1e-06);
}
END_TEST

START_TEST(pow_48) {
  ck_assert_ldouble_eq_tol(s21_pow(2, 18), pow(2, 18), 1e-06);
}
END_TEST

START_TEST(pow_49) {
  ck_assert_ldouble_eq_tol(s21_pow(2.1, 11), pow(2.1, 11), 1e-06);
}
END_TEST

START_TEST(pow_50) {
  ck_assert_ldouble_eq_tol(s21_pow(1.23456e-7, 2.21), pow(1.23456e-7, 2.21),
                           1e-06);
}
END_TEST

START_TEST(pow_51) {
  ck_assert_ldouble_eq_tol(s21_pow(2.1234567, -2), pow(2.1234567, -2), 1e-06);
}
END_TEST

START_TEST(pow_52) {
  ck_assert_ldouble_eq_tol(s21_pow(2.1234567, -2), pow(2.1234567, -2), 1e-06);
}
END_TEST

START_TEST(pow_53) {
  long double orig_res = pow(2.1234567e-7, -2.45e4),
              our_res = s21_pow(2.1234567e-7, -2.45e4);
  int suc = 0;
  if (isinf(our_res) && isinf(orig_res)) suc = 1;
  ck_assert_int_eq(1, suc);
}
END_TEST

START_TEST(pow_54) {
  ck_assert_ldouble_eq_tol(s21_pow(9.99999999e3, 9.95e-4),
                           pow(9.99999999e3, 9.95e-4), 1e-06);
}
END_TEST

START_TEST(pow_55) { ck_assert_ldouble_infinite(s21_pow(+0, -12)); }
END_TEST

START_TEST(pow_56) { ck_assert_ldouble_infinite(s21_pow(-0, -12)); }
END_TEST

START_TEST(pow_57) {
  ck_assert_ldouble_eq_tol(s21_pow(-0, 0), pow(-0, 0), 1e-06);
}
END_TEST

START_TEST(pow_58) {
  ck_assert_double_nan(s21_pow(+0, S21_NAN));
  ck_assert_double_nan(pow(+0, S21_NAN));
}
END_TEST

START_TEST(pow_59) {
  ck_assert_ldouble_eq_tol(s21_pow(+0, 2.456), pow(+0, 2.456), 1e-06);
}
END_TEST

START_TEST(pow_60) {
  ck_assert_ldouble_infinite(s21_pow(+0, S21_NINF));
  ck_assert_ldouble_infinite(pow(+0, S21_NINF));
}
END_TEST

START_TEST(pow_60_2) {
  ck_assert_ldouble_eq_tol(s21_pow(+0, 56), pow(+0, 56), 1e-06);
}
END_TEST

START_TEST(pow_61) {
  ck_assert_ldouble_eq_tol(s21_pow(-0, 56), pow(-0, 56), 1e-06);
}
END_TEST

START_TEST(pow_62) {
  ck_assert_ldouble_eq_tol(s21_pow(-0, 56.345), pow(-0, 56.345), 1e-06);
}
END_TEST

START_TEST(pow_63) {
  ck_assert_ldouble_eq_tol(s21_pow(-1, S21_INF), pow(-1, S21_INF), 1e-06);
}
END_TEST

START_TEST(pow_64) {
  ck_assert_ldouble_eq_tol(s21_pow(-1, S21_INF), pow(-1, S21_INF), 1e-06);
}
END_TEST

START_TEST(pow_65) {
  ck_assert_ldouble_eq_tol(s21_pow(+1, S21_NAN), pow(+1, S21_NAN), 1e-06);
}
END_TEST

START_TEST(pow_66) {
  ck_assert_ldouble_eq_tol(s21_pow(4567, -0), pow(4567, -0), 1e-06);
}
END_TEST

START_TEST(pow_67) {
  ck_assert_ldouble_eq_tol(s21_pow(34567, 0), pow(34567, 0), 1e-06);
}
END_TEST

START_TEST(pow_68) {
  ck_assert_ldouble_eq_tol(s21_pow(S21_NAN, -0), pow(S21_NAN, -0), 1e-06);
}
END_TEST

START_TEST(pow_69) {
  ck_assert_ldouble_eq_tol(s21_pow(S21_NAN, 0), pow(S21_NAN, 0), 1e-06);
}
END_TEST

START_TEST(pow_70) {
  ck_assert_double_nan(s21_pow(S21_NAN, S21_NAN));
  ck_assert_double_nan(pow(S21_NAN, S21_NAN));
}
END_TEST

START_TEST(pow_71) {
  ck_assert_ldouble_infinite(s21_pow(S21_INF, S21_INF));
  ck_assert_ldouble_infinite(pow(S21_INF, S21_INF));
}
END_TEST

START_TEST(pow_72) {
  ck_assert_ldouble_eq_tol(s21_pow(S21_NINF, S21_NINF), pow(S21_NINF, S21_NINF),
                           1e-06);
}
END_TEST

START_TEST(pow_73) {
  ck_assert_ldouble_infinite(s21_pow(S21_NINF, S21_INF));
  ck_assert_ldouble_infinite(pow(S21_NINF, S21_INF));
}
END_TEST

START_TEST(pow_74) {
  double exp = 0;
  double res1 = 0;
  long double res2 = 0;
  for (exp = 0.0; exp > -1000; exp -= 0.1) {
    res1 = pow(S21_INF, exp);
    res2 = s21_pow(S21_INF, exp);
  }
  ck_assert_ldouble_eq_tol(res1, res2, 1e-06);
}
END_TEST

START_TEST(pow_75) {
  double base = 0;
  double res1 = 0;
  long double res2 = 0;
  for (base = 0.0; base < 10; base += 0.1) {
    res1 = pow(base, S21_INF);
    res2 = s21_pow(base, S21_INF);
  }
  ck_assert_ldouble_infinite(res1);
  ck_assert_ldouble_infinite(res2);
}
END_TEST

START_TEST(pow_76) {
  double base = 0;
  double res1 = 0;
  long double res2 = 0;
  for (base = 0.0; base > -10; base -= 0.1) {
    res1 = pow(base, S21_INF);
    res2 = s21_pow(base, S21_INF);
  }
  ck_assert_ldouble_infinite(res1);
  ck_assert_ldouble_infinite(res2);
}
END_TEST

START_TEST(pow_77) {
  long double base = 0;
  long double res1 = 0;
  long double res2 = 0;
  for (base = 0.0; base < 10; base += 0.1) {
    res1 = pow(base, S21_NINF);
    res2 = s21_pow(base, S21_NINF);
  }
  ck_assert_ldouble_eq_tol(res1, res2, 1e-06);
}
END_TEST

START_TEST(pow_78) {
  long double base = 0;
  long double res1 = 0;
  long double res2 = 0;
  for (base = 0.0; base > -10; base -= 0.1) {
    res1 = pow(base, S21_NINF);
    res2 = s21_pow(base, S21_NINF);
  }
  ck_assert_ldouble_eq_tol(res1, res2, 1e-06);
}
END_TEST

START_TEST(pow_79) {
  double exp = 0;
  double res1 = 0;
  long double res2 = 0;
  for (exp = 0.0; exp > -10; exp -= 0.1) {
    if (fmod(exp, 2) != 0) {
      res1 = pow(S21_NINF, exp);
      res2 = s21_pow(S21_NINF, exp);
    }
  }
  ck_assert_ldouble_eq_tol(res1, res2, 1e-06);
}
END_TEST

START_TEST(pow_80) {
  double exp = 0;
  double res1 = 0;
  long double res2 = 0;
  for (exp = 0.0; exp > -10; exp -= 0.1) {
    if (fmod(exp, 2) == 0) {
      res1 = pow(S21_NINF, exp);
      res2 = s21_pow(S21_NINF, exp);
    }
  }
  ck_assert_ldouble_eq_tol(res1, res2, 1e-06);
}
END_TEST

START_TEST(pow_81) {
  double exp = 0;
  double res1 = 0;
  long double res2 = 0;
  for (exp = 0.0; exp < 10; exp += 0.1) {
    if (fmod(exp, 2) != 0) {
      res1 = pow(S21_NINF, exp);
      res2 = s21_pow(S21_NINF, exp);
    }
  }
  ck_assert_ldouble_infinite(res1);
  ck_assert_ldouble_infinite(res2);
}
END_TEST

START_TEST(pow_82) {
  double exp = 0;
  double res1 = 0;
  long double res2 = 0;
  for (exp = 0.0; exp < 10; exp += 0.1) {
    if (fmod(exp, 2) == 0) {
      res1 = pow(S21_NINF, exp);
      res2 = s21_pow(S21_NINF, exp);
    }
  }
  ck_assert_ldouble_eq_tol(res2, res1, 1e-06);
}
END_TEST

START_TEST(pow_83) {
  long double exp = 3;
  ck_assert_ldouble_eq_tol(s21_pow(-3, exp), pow(-3, exp), 1e-06);
}
END_TEST

START_TEST(pow_84) {
  long double exp = -3;
  ck_assert_ldouble_eq_tol(s21_pow(-3, exp), pow(-3, exp), 1e-06);
}
END_TEST

START_TEST(pow_85) {
  long double exp = -3;
  ck_assert_ldouble_eq_tol(s21_pow(3, exp), pow(3, exp), 1e-06);
}
END_TEST

START_TEST(pow_86) {
  long double exp = 3;
  ck_assert_ldouble_eq_tol(s21_pow(3, exp), pow(3, exp), 1e-06);
}
END_TEST

START_TEST(pow_87) {
  long double base = -0;
  long double exp = S21_INF;
  long double res = pow(base, exp);
  long double res1 = s21_pow(base, exp);
  ck_assert_ldouble_eq_tol(res, res1, 1e-06);
}
END_TEST

START_TEST(pow_88) {
  long double exp = 0;
  long double base = -0;
  long double res = 0;
  long double res1 = 0;
  for (exp = 0.0; exp < 10; exp += 0.1) {
    if (fmod(exp, 2) != 0) {
      res = pow(base, exp);
      res1 = s21_pow(base, exp);
    }
  }
  ck_assert_ldouble_eq_tol(res, res1, 1e-06);
}
END_TEST

int main(void) {
  Suite *s1 = suite_create("Core");
  TCase *tc1_1 = tcase_create("Core");
  SRunner *sr = srunner_create(s1);
  int nf;

  suite_add_tcase(s1, tc1_1);
  tcase_add_test(tc1_1, absTest_1);
  tcase_add_test(tc1_1, absTest_2);
  tcase_add_test(tc1_1, absTest_3);
  tcase_add_test(tc1_1, acosTest_1);
  tcase_add_test(tc1_1, acosTest_2);
  tcase_add_test(tc1_1, acosTest_3);
  tcase_add_test(tc1_1, acosTest_4);
  tcase_add_test(tc1_1, acosTest_5);
  tcase_add_test(tc1_1, acosTest_6);
  tcase_add_test(tc1_1, asinTest_1);
  tcase_add_test(tc1_1, asinTest_2);
  tcase_add_test(tc1_1, asinTest_3);
  tcase_add_test(tc1_1, asinTest_4);
  tcase_add_test(tc1_1, atanTest_1);
  tcase_add_test(tc1_1, atanTest_2);
  tcase_add_test(tc1_1, atanTest_3);
  tcase_add_test(tc1_1, atanTest_4);
  tcase_add_test(tc1_1, atanTest_5);
  tcase_add_test(tc1_1, ceilTest_1);
  tcase_add_test(tc1_1, ceilTest_2);
  tcase_add_test(tc1_1, ceilTest_3);
  tcase_add_test(tc1_1, ceilTest_4);
  tcase_add_test(tc1_1, cosTest_1);
  tcase_add_test(tc1_1, cosTest_2);
  tcase_add_test(tc1_1, cosTest_3);
  tcase_add_test(tc1_1, expTest_1);
  tcase_add_test(tc1_1, expTest_2);
  tcase_add_test(tc1_1, expTest_3);
  tcase_add_test(tc1_1, expTest_4);
  tcase_add_test(tc1_1, fabsTest_1);
  tcase_add_test(tc1_1, fabsTest_2);
  tcase_add_test(tc1_1, fabsTest_3);
  tcase_add_test(tc1_1, floorTest_1);
  tcase_add_test(tc1_1, floorTest_2);
  tcase_add_test(tc1_1, floorTest_3);
  tcase_add_test(tc1_1, floorTest_4);
  tcase_add_test(tc1_1, floorTest_5);
  tcase_add_test(tc1_1, floorTest_6);
  tcase_add_test(tc1_1, floorTest_7);
  tcase_add_test(tc1_1, fmodTest_1);
  tcase_add_test(tc1_1, fmodTest_2);
  tcase_add_test(tc1_1, fmodTest_3);
  tcase_add_test(tc1_1, fmodTest_6);
  tcase_add_test(tc1_1, fmodTest_4);
  tcase_add_test(tc1_1, fmodTest_5);
  tcase_add_test(tc1_1, logTest_1);
  tcase_add_test(tc1_1, logTest_2);
  tcase_add_test(tc1_1, logTest_3);
  tcase_add_test(tc1_1, logTest_4);
  tcase_add_test(tc1_1, logTest_5);
  tcase_add_test(tc1_1, logTest_6);
  tcase_add_test(tc1_1, logTest_7);
  tcase_add_test(tc1_1, logTest_8);
  tcase_add_test(tc1_1, logTest_9);
  tcase_add_test(tc1_1, logTest_10);
  tcase_add_test(tc1_1, powTest_1);
  tcase_add_test(tc1_1, powTest_2);
  tcase_add_test(tc1_1, powTest_3);
  tcase_add_test(tc1_1, powTest_4);
  tcase_add_test(tc1_1, powTest_5);
  tcase_add_test(tc1_1, powTest_6);
  tcase_add_test(tc1_1, powTest_7);
  tcase_add_test(tc1_1, powTest_8);
  tcase_add_test(tc1_1, powTest_10);
  tcase_add_test(tc1_1, powTest_11);
  tcase_add_test(tc1_1, powTest_12);
  tcase_add_test(tc1_1, powTest_13);
  tcase_add_test(tc1_1, powTest_14);
  tcase_add_test(tc1_1, powTest_15);
  tcase_add_test(tc1_1, powTest_16);
  tcase_add_test(tc1_1, powTest_17);
  tcase_add_test(tc1_1, powTest_18);
  tcase_add_test(tc1_1, powTest_19);
  tcase_add_test(tc1_1, powTest_21);
  tcase_add_test(tc1_1, powTest_22);
  tcase_add_test(tc1_1, powTest_23);
  tcase_add_test(tc1_1, powTest_24);
  tcase_add_test(tc1_1, powTest_25);
  tcase_add_test(tc1_1, powTest_26);
  tcase_add_test(tc1_1, powTest_27);
  tcase_add_test(tc1_1, powTest_28);
  tcase_add_test(tc1_1, powTest_29);
  tcase_add_test(tc1_1, powTest_30);
  tcase_add_test(tc1_1, powTest_31);
  tcase_add_test(tc1_1, sinTest_1);
  tcase_add_test(tc1_1, sinTest_2);
  tcase_add_test(tc1_1, sinTest_3);
  tcase_add_test(tc1_1, sinTest_4);
  tcase_add_test(tc1_1, sqrtTest_1);
  tcase_add_test(tc1_1, sqrtTest_2);
  tcase_add_test(tc1_1, sqrtTest_3);
  tcase_add_test(tc1_1, sqrtTest_4);
  tcase_add_test(tc1_1, sqrtTest_5);
  tcase_add_test(tc1_1, tanTest_1);
  tcase_add_test(tc1_1, tanTest_2);
  tcase_add_test(tc1_1, tanTest_3);
  tcase_add_test(tc1_1, tanTest_4);
  tcase_add_test(tc1_1, pow_1);
  tcase_add_test(tc1_1, pow_2);
  tcase_add_test(tc1_1, pow_3);
  tcase_add_test(tc1_1, pow_4);
  tcase_add_test(tc1_1, pow_5);
  tcase_add_test(tc1_1, pow_6);
  tcase_add_test(tc1_1, pow_7);
  tcase_add_test(tc1_1, pow_8);
  tcase_add_test(tc1_1, pow_9);
  tcase_add_test(tc1_1, pow_10);
  tcase_add_test(tc1_1, pow_11);
  tcase_add_test(tc1_1, pow_12);
  tcase_add_test(tc1_1, pow_13);
  tcase_add_test(tc1_1, pow_14);
  tcase_add_test(tc1_1, pow_15);
  tcase_add_test(tc1_1, pow_16);
  tcase_add_test(tc1_1, pow_17);
  tcase_add_test(tc1_1, pow_19);
  tcase_add_test(tc1_1, pow_20);
  tcase_add_test(tc1_1, pow_21);
  tcase_add_test(tc1_1, pow_22);
  tcase_add_test(tc1_1, pow_23);
  tcase_add_test(tc1_1, pow_24);
  tcase_add_test(tc1_1, pow_25);
  tcase_add_test(tc1_1, pow_26);
  tcase_add_test(tc1_1, pow_27);
  tcase_add_test(tc1_1, pow_28);
  tcase_add_test(tc1_1, pow_29);
  tcase_add_test(tc1_1, pow_30);
  tcase_add_test(tc1_1, pow_31);
  tcase_add_test(tc1_1, pow_32);
  tcase_add_test(tc1_1, pow_33);
  tcase_add_test(tc1_1, pow_34);
  tcase_add_test(tc1_1, pow_35);
  tcase_add_test(tc1_1, pow_36);
  tcase_add_test(tc1_1, pow_37);
  tcase_add_test(tc1_1, pow_38);
  tcase_add_test(tc1_1, pow_39);
  tcase_add_test(tc1_1, pow_40);
  tcase_add_test(tc1_1, pow_41);
  tcase_add_test(tc1_1, pow_42);
  tcase_add_test(tc1_1, pow_43);
  tcase_add_test(tc1_1, pow_44);
  tcase_add_test(tc1_1, pow_45);
  tcase_add_test(tc1_1, pow_46);
  tcase_add_test(tc1_1, pow_47);
  tcase_add_test(tc1_1, pow_48);
  tcase_add_test(tc1_1, pow_49);
  tcase_add_test(tc1_1, pow_50);
  tcase_add_test(tc1_1, pow_51);
  tcase_add_test(tc1_1, pow_52);
  tcase_add_test(tc1_1, pow_53);
  tcase_add_test(tc1_1, pow_54);
  tcase_add_test(tc1_1, pow_55);
  tcase_add_test(tc1_1, pow_56);
  tcase_add_test(tc1_1, pow_57);
  tcase_add_test(tc1_1, pow_58);
  tcase_add_test(tc1_1, pow_59);
  tcase_add_test(tc1_1, pow_60);
  tcase_add_test(tc1_1, pow_60_2);
  tcase_add_test(tc1_1, pow_61);
  tcase_add_test(tc1_1, pow_62);
  tcase_add_test(tc1_1, pow_63);
  tcase_add_test(tc1_1, pow_64);
  tcase_add_test(tc1_1, pow_65);
  tcase_add_test(tc1_1, pow_66);
  tcase_add_test(tc1_1, pow_67);
  tcase_add_test(tc1_1, pow_68);
  tcase_add_test(tc1_1, pow_69);
  tcase_add_test(tc1_1, pow_70);
  tcase_add_test(tc1_1, pow_71);
  tcase_add_test(tc1_1, pow_72);
  tcase_add_test(tc1_1, pow_73);
  tcase_add_test(tc1_1, pow_74);
  tcase_add_test(tc1_1, pow_75);
  tcase_add_test(tc1_1, pow_76);
  tcase_add_test(tc1_1, pow_77);
  tcase_add_test(tc1_1, pow_78);
  tcase_add_test(tc1_1, pow_79);
  tcase_add_test(tc1_1, pow_80);
  tcase_add_test(tc1_1, pow_81);
  tcase_add_test(tc1_1, pow_82);
  tcase_add_test(tc1_1, pow_83);
  tcase_add_test(tc1_1, pow_84);
  tcase_add_test(tc1_1, pow_85);
  tcase_add_test(tc1_1, pow_86);
  tcase_add_test(tc1_1, pow_87);
  tcase_add_test(tc1_1, pow_88);

  srunner_run_all(sr, CK_ENV);
  nf = srunner_ntests_failed(sr);
  srunner_free(sr);

  return nf == 0 ? 0 : 1;
}
